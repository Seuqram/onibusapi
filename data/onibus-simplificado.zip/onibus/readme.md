## TODO

* classe que posiciona os ve�culos nos segmentos da trilha

PS: vamos trabalhar com coordenadas euclidianas em um primeiro momento

PS: implementar alguma coisa para mostrar os resultados em casos reais
