package onibus.modelo;

import lombok.Data;

/**
 * Classe que representa um ponto em um caminho
 * 
 * @author Marcio Barros
 */
public @Data class Ponto
{
	private double x;
	private double y;

	public Ponto(double x, double y)
	{
		this.x = x;
		this.y = y;
	}
}