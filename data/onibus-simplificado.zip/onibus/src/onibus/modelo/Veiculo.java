package onibus.modelo;

import lombok.Getter;

/**
 * Classe que representa um ve�culo de uma linha
 * 
 * @author Marcio Barros
 */
public class Veiculo
{
	private @Getter String id;
	private @Getter Ponto posicao;
	
	public Veiculo(String id, double x, double y)
	{
		this.id = id;
		this.posicao = new Ponto(x, y);
	}
}
