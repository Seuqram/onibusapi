package onibus.modelo;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;

/**
 * Classe que representa uma linha de �nibus
 * 
 * @author Marcio Barros
 */
public class Linha
{
	private List<Veiculo> veiculos;
	private @Getter Caminho caminho;

	/**
	 * Inicializa a linha
	 */
	public Linha(Caminho caminho)
	{
		this.caminho = caminho;
		this.veiculos = new ArrayList<Veiculo>();
	}

	/**
	 * Conta o n�mero de ve�culos
	 */
	public int contaVeiculos()
	{
		return veiculos.size();
	}
	
	/**
	 * Retorna um ve�culo, dado seu �ndice
	 */
	public Veiculo pegaVeiculoIndice(int indice)
	{
		return veiculos.get(indice);
	}

	/**
	 * Retorna todos os ve�culos
	 */
	public Iterable<Veiculo> getVeiculos()
	{
		return veiculos;
	}

	/**
	 * Adiciona um ve�culo na linha
	 */
	public void adicionaVeiculo(String id, double x, double y)
	{
		adicionaVeiculo(new Veiculo(id, x, y));
	}
	
	/**
	 * Adiciona um ve�culo na linha
	 */
	public void adicionaVeiculo(Veiculo veiculo)
	{
		veiculos.add(veiculo);
	}

	/**
	 * Remove todos os ve�culos da linha
	 */
	public void limpaVeiculos()
	{
		veiculos.clear();
	}
}