package onibus.modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa um caminho seguido por um ve�culo. Importante notar que o
 * caminho deve ser fechado, ou seja, o �ltimo ponto deve ser igual ao primeiro.
 * 
 * @author Marcio Barros
 */
public class Caminho
{
	private List<Ponto> pontos;

	/**
	 * Inicializa o caminho
	 */
	public Caminho()
	{
		this.pontos = new ArrayList<Ponto>();
	}
	
	/**
	 * Conta o n�mero de pontos no caminho
	 */
	public int conta()
	{
		return pontos.size();
	}
	
	/**
	 * Retorna um ponto do caminho, dado seu �ndice
	 */
	public Ponto pegaPontoIndice(int indice)
	{
		return pontos.get(indice);
	}
	
	/**
	 * Retorna todos os pontos do caminho
	 */
	public Iterable<Ponto> getPontos()
	{
		return pontos;
	}
	
	/**
	 * Adiciona um ponto no caminho
	 */
	public void adiciona(double x, double y)
	{
		pontos.add(new Ponto(x, y));
	}

	/**
	 * Calcula a dist�ncia de um ponto a partir do primeiro ponto do caminho
	 */
	public double calculaDistancia(Ponto p)
	{
		double distancia = 0.0;
		
		for (int i = 1; i < pontos.size(); i++)
		{
			Ponto p1 = pontos.get(i-1);
			Ponto p2 = pontos.get(i);
			
			if (pertenceSegmento(p, p1, p2))
				return distancia + distancia(p1, p);
			
			distancia += distancia(p1, p2);
		}
		
		return -1;
	}

	/**
	 * Verifica se um ponto est� em um segmento do caminho
	 */
	private boolean pertenceSegmento(Ponto p, Ponto p1, Ponto p2)
	{
		if (Math.abs(p1.getX() - p2.getX()) < 0.0000001)
		{
			if (Math.abs(p.getX() - p1.getX()) < 0.0000001)
			{
				double maxY = Math.max(p1.getY(), p2.getY());
				double minY = Math.min(p1.getY(), p2.getY());
				return p.getY() >= minY && p.getY() <= maxY;
			}
			
			return false;
		}
		
		double maxX = Math.max(p1.getX(), p2.getX());
		double minX = Math.min(p1.getX(), p2.getX());
		
		if (p.getX() >= minX && p.getX() <= maxX)
		{
			double a = (p1.getY() - p2.getY()) / (p1.getX() - p2.getX());
			double b = p2.getY() - p2.getX() * a;
			double ye = a * p.getX() + b;
			return (Math.abs(p.getY() - ye) < 0.0000001);
		}
		
		return false;
	}

	/**
	 * Calcula a dist�ncia entre dois pontos
	 */
	private double distancia(Ponto p1, Ponto p2)
	{
		return Math.sqrt(Math.pow(p2.getX() - p1.getX(), 2) + Math.pow(p2.getY() - p1.getY(), 2));
	}

	/**
	 * Retorna o comprimento do caminho
	 */
	public double pegaComprimento()
	{
		double distancia = 0.0;
		
		for (int i = 1; i < pontos.size(); i++)
		{
			Ponto p1 = pontos.get(i-1);
			Ponto p2 = pontos.get(i);
			distancia += distancia(p1, p2);
		}
		
		return distancia;
	}
}