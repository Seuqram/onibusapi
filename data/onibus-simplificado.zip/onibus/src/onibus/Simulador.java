package onibus;

import onibus.modelo.Caminho;
import onibus.modelo.Linha;

public class Simulador
{
	public static final void main(String[] args)
	{
		Caminho caminho = new Caminho();
		caminho.adiciona(0, 0);
		caminho.adiciona(0, 10);
		caminho.adiciona(10, 10);
		caminho.adiciona(10, 0);
		caminho.adiciona(0, 0);
		
		for (int i = 0; i <= 10; i++)
			apresentaIndice(caminho, i, 0.0, i);
		
		for (int i = 11; i <= 20; i++)
			apresentaIndice(caminho, i, i - 10, 10);
	}

	private static void apresentaIndice(Caminho caminho, int posicao, double x, double y)
	{
		Linha linha = new Linha(caminho);
		linha.adicionaVeiculo("1", 0, 0);
		linha.adicionaVeiculo("2", x, y);
		linha.adicionaVeiculo("3", 10, 10);
		linha.adicionaVeiculo("4", 10, 0);
		
		CalculadorIQR calculador = new CalculadorIQR();
		double indice = calculador.executa(linha);
		System.out.println(posicao + ": " + indice);
	}
}