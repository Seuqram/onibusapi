package onibus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import lombok.Data;
import onibus.modelo.Linha;
import onibus.modelo.Veiculo;

/**
 * Classe que calcula o �ndice de qualidade na rota
 * 
 * @author Marcio Barros
 */
public class CalculadorIQR
{
	/**
	 * Calcula o �ndice de qualidade na rota para uma linha
	 */
	public double executa(Linha linha)
	{
		// N�o � poss�vel calcular o �ndice com menos de dois ve�culos
		if (linha.contaVeiculos() < 2)
			return -1;

		// Se todos os ve�culos est�o na mesma posi��o, temos o pior caso 
		if (todosVeiculosMesmaPosicao(linha))
			return 0.0;
		
		// Calcula as dist�ncias dos ve�culos na trilha
		List<DistanciaVeiculo> distanciasTrilha = calculaDistanciaTrilha(linha);

		// Ordena os ve�culos pela dist�ncia
		Collections.sort(distanciasTrilha, new DistanciaVeiculoComparator());

		// Calcula o comprimento da trilha
		double comprimento = linha.getCaminho().pegaComprimento();
		
		// Calcula as distancias entre os veiculos
		double[] distanciasVeiculos = new double[linha.contaVeiculos()];
		distanciasVeiculos[linha.contaVeiculos()-1] = comprimento - distanciasTrilha.get(linha.contaVeiculos()-1).getDistancia() + distanciasTrilha.get(0).getDistancia();
				
		for (int i = 0; i < linha.contaVeiculos()-1; i++)
			distanciasVeiculos[i] = distanciasTrilha.get(i+1).getDistancia() - distanciasTrilha.get(i).getDistancia();
		
		// Calcula a distancia ideal entre os veiculos. A distribui��o ideal � um ponto no R(N)
		// cujo valor � "distanciaIdeal", onde N � igual ao n�mero de ve�culos
		double distanciaIdeal = comprimento / linha.contaVeiculos();

		// O ponto mais distante possivel em que as coordenadas somem "comprimento" ser� o ponto
		// em que todas as coordenadas s�o zero e a �ltima coordenada � "comprimento"
		double distanciaMaxima = Math.sqrt((linha.contaVeiculos()-1) * Math.pow(distanciaIdeal, 2) + Math.pow((linha.contaVeiculos() - 1) * distanciaIdeal, 2));
		
		// Calcula a dist�ncia do ponto de interesse de qualidade
		double indice = 0.0;
		
		for (int i = 0; i < linha.contaVeiculos(); i++)
			indice += Math.pow(distanciasVeiculos[i] - distanciaIdeal, 2);
		
		// Calcula o �ndice
		return 1 - Math.sqrt(indice) / distanciaMaxima;
	}

	/**
	 * Calcula as dist�ncias na trilha para todos os ve�culos
	 */
	private List<DistanciaVeiculo> calculaDistanciaTrilha(Linha linha)
	{
		List<DistanciaVeiculo> distancias = new ArrayList<DistanciaVeiculo>();
		
		for (int i = 0; i < linha.contaVeiculos(); i++)
		{
			Veiculo veiculo = linha.pegaVeiculoIndice(i);
			double distancia = linha.getCaminho().calculaDistancia(veiculo.getPosicao());
			
			DistanciaVeiculo entrada = new DistanciaVeiculo();
			entrada.setVeiculo(veiculo);
			entrada.setDistancia(distancia);
			distancias.add(entrada);
		}

		return distancias;
	}

	/**
	 * Verifica se todos os �nibus est�o na mesma posi��o
	 */
	private boolean todosVeiculosMesmaPosicao(Linha linha)
	{
		Veiculo veiculo = linha.pegaVeiculoIndice(0);
		double x = veiculo.getPosicao().getX();
		double y = veiculo.getPosicao().getY();
		
		for (int i = 1; i < linha.contaVeiculos(); i++)
		{
			veiculo = linha.pegaVeiculoIndice(i);
			
			if (Math.abs(x - veiculo.getPosicao().getX()) > 0.001)
				return false;
			
			if (Math.abs(y - veiculo.getPosicao().getY()) > 0.001)
				return false;
		}
		
		return true;
	}

	/**
	 * Classe que representa a dist�ncia na trilha de cada ve�culo
	 * 
	 * @author Marcio Barros
	 */
	private @Data class DistanciaVeiculo
	{
		private Veiculo veiculo;
		private double distancia;
	}
	
	/**
	 * Classe que compara duas dist�ncias entre ve�culos
	 * 
	 * @author Marcio Barros
	 */
	private final class DistanciaVeiculoComparator implements Comparator<DistanciaVeiculo>
	{
		@Override
		public int compare(DistanciaVeiculo dv1, DistanciaVeiculo dv2)
		{
			if (dv1.getDistancia() < dv2.getDistancia())
				return -1;
			
			if (dv1.getDistancia() > dv2.getDistancia())
				return 1;
			
			return 0;
		}
	}
}