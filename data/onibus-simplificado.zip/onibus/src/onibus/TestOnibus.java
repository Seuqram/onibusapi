package onibus;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import onibus.modelo.Caminho;
import onibus.modelo.Linha;

public class TestOnibus
{
	@Test
	public void testMelhorCaso()
	{
		Caminho caminho = new Caminho();
		caminho.adiciona(0, 0);
		caminho.adiciona(0, 10);
		caminho.adiciona(10, 10);
		caminho.adiciona(10, 0);
		caminho.adiciona(0, 0);
		
		Linha linha = new Linha(caminho);
		linha.adicionaVeiculo("1", 0, 0);
		linha.adicionaVeiculo("2", 0, 10);
		linha.adicionaVeiculo("3", 10, 10);
		linha.adicionaVeiculo("4", 10, 0);
		
		CalculadorIQR calculador = new CalculadorIQR();
		double indice = calculador.executa(linha);
		
		System.out.println("MC: " + indice);
		assertTrue(true);
	}

	@Test
	public void testPiorCaso()
	{
		Caminho caminho = new Caminho();
		caminho.adiciona(0, 0);
		caminho.adiciona(0, 10);
		caminho.adiciona(10, 10);
		caminho.adiciona(10, 0);
		caminho.adiciona(0, 0);
		
		Linha linha = new Linha(caminho);
		linha.adicionaVeiculo("1", 0, 0);
		linha.adicionaVeiculo("2", 0, 0);
		linha.adicionaVeiculo("3", 0, 0);
		linha.adicionaVeiculo("4", 0.01, 0);
		
		CalculadorIQR calculador = new CalculadorIQR();
		double indice = calculador.executa(linha);
		
		System.out.println("PC: " + indice);
		assertTrue(true);
	}
}